public interface Koperasi {
    int LoanMonthly();
}